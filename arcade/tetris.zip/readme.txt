TINYTRIS v1.6

Date:          09/04
Author:        Ben Hanke
E-Mail:        ben@13h.org
Web:           http://13h.org
Licence:       Freeware

Classic GameBoy Tetris approximated in
under 3KB. Runs on MS-DOS, Win9x/ME/2000/XP
Instructions:  Use arrow keys to move, Z/X 
to rotate and SPACE to drop.

Special thanks to:

Theodor Lauppert [http://members.chello.at/theodor.lauppert]
Rudy Versele of Caiman Free Games [http://www.caiman.us]

Follow me on twitter - http://twitter.com/repstos